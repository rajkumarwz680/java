package java_practice;

public class print {
	public static void main(String[] args) {
		System.out.println("FirstLine");
		System.out.print("SecondLine");
		System.out.println("Thirdline");
		System.out.print("FourthLine");

	}

}

