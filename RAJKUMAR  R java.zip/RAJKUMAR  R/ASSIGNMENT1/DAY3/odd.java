package java_practice;

public class odd {
	
		public static void main(String[] args)
		{
			for(int i=0;i<=10;i=i+1)
			{
				if(i%2!=0)
					System.out.print(i+" ");
			}
		}

	}

