package java_practice;
import java.util.Scanner;
public class eligibletovote {
	public static void main(String[] args)
	{
		Scanner obj=new Scanner(System.in);
		System.out.print("Enter your Age:");
		int age=obj.nextInt();
		if(age>=18)
			System.out.print("Elgible for voting");
		else
			System.out.print("Not Eligible");
		
	}


}
